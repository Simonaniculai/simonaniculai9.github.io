<?php if ( is_active_sidebar( 'envo-business-right-sidebar' ) ) { ?>
	<aside id="sidebar" class="main-sidebar col-md-3">
		<?php dynamic_sidebar( 'envo-business-right-sidebar' ); ?>
	</aside>
<?php } ?>
